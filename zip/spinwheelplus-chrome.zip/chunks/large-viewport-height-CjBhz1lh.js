import{c as o}from"../sidepanel.js";/**
 * @license lucide-react v0.544.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]],a=o("rotate-ccw",r);let t=null,n=null;const c=()=>typeof window>"u"?"":`${window.innerWidth}x${window.innerHeight}`,d=()=>{if(typeof document>"u")return 0;const e=document.createElement("div");e.style.cssText="position:fixed;top:0;left:0;width:0;height:100lvh;visibility:hidden;pointer-events:none;",document.documentElement.appendChild(e);const i=e.getBoundingClientRect().height;return e.remove(),i},s=()=>{const e=c();return(t==null||n!==e)&&(t=d(),n=e),t},l=()=>{t=null,n=null};export{a as R,s as g,l as r};
